import pandas as pd

class DataPrepairer:
    def __init__(self, data):
        self.data = data
    
    def handle_missing_values(self, method='interpolate'):
        data_copy = self.data.copy()
        missing_report = data_copy.isna().sum()
        print(f" Missing values per column report: {missing_report}")
        print(f" Total missing values: {missing_report.sum()}")
        if missing_report.sum() > 0:
            # self.data = self.data.fillna(method='ffill').fillna(method='bfill')
            print(f"❌ Missing values detected. Applying linear interpolation...")
            self.data.iloc[:, 1:] = self.data.iloc[:, 1:].interpolate(
                method='linear', limit_direction='both'
            )
            print(f"✅ Successfully applied linear interpolation.")
            missing_after = self.data.isna().sum()
            print(f" Missing values per column after interpolation: {missing_after}")
        else:
            print(f"✅ No missing values detected. Moving on...")
        
        self.data = data_copy
    
    def handle_duplicates(self, subset_cols):
        data_copy = self.data.copy()
        duplicate_count = data_copy.duplicated(subset=subset_cols).sum()
        if duplicate_count > 0:
            print(f"❌ Detected {duplicate_count} duplicate rows based on columns {subset_cols}. Removing duplicates...")
            data_copy = data_copy.drop_duplicates(subset=subset_cols)
            print(f"✅ Successfully removed duplicates.")
        else:
            print(f"✅ No duplicate rows detected based on columns {subset_cols}. Moving on...")
        self.data = data_copy
    
    def convert_date_to_julian(self, time_col):
        try:
            data_copy = self.data.copy()
            # Convert 'time' column to Julian date format
            data_copy['Julian_Date'] = pd.to_datetime(data_copy[time_col], errors='coerce').dt.dayofyear
            print(f"✅ Successfully converted '{time_col}' to Julian date format.")
        except Exception as e:
            print(f"❌ Error converting '{time_col}': {e}")
        self.data = data_copy
    
    def normalize_feature_names(self):
        data_copy = self.data.copy()
        # Normalize feature names: lowercase and replace spaces with underscores
        data_copy.columns = [col.strip().lower().replace(' ', '_') for col in data_copy.columns]
        print(f"✅ Successfully normalized feature names.")
        self.data = data_copy