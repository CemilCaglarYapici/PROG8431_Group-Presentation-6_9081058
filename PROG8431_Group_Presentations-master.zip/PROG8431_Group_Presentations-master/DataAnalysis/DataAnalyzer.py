class DataAnalyzer:
    def __init__(self, data):
        self.data = data
    
    def data_analysis(self):
        print(" Data Analysis Report:")
        print(f" - Number of rows: {self.data.shape[0]}")
        print(f" - Number of columns: {self.data.shape[1]}")
        print(f" - Column names: {self.data.columns.tolist()}")
        print(f" - Data types:\n{self.data.dtypes}")
        print(f" - Summary statistics:\n{self.data.describe(include='all')}")
        print(f" - Missing values per column:\n{self.data.isna().sum()}")

    def outlier_detection(self, column):
        q1 = self.data[column].quantile(0.25)
        q3 = self.data[column].quantile(0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        outliers = self.data[(self.data[column] < lower_bound) | (self.data[column] > upper_bound)]
        print(f"✅{len(outliers)} Outliers detected for column '{column}': {outliers.index.tolist()}")
    