### Group Presentation 5

Before the due date:

1. Add new data sources to your term project - Understand all the collected data and become competent at explaining it in 1 minute or less.
2. Continue to encapsulate all the Jupyter Notebook code in classes and methods.
3. Write a 100-word summary update of the use case, including a revised hypothesis testing (an update to the one in the previous group presentation)
4. Implement a simple linear regression model suitable for the purposes and targets of your term project.
5. Perform the following analyses in code cells and discuss each in a separate markdown cell in the Jupyter Notebook.
    * All the techniques implemented for the Group Presentation 4, plus: 
    * Homoscedasticity
    * R-Squared Measure
6. Prepare a 3-5 minute presentation using the notebook as a guide. Please note that the 5-minute mark is a hard stop.
7. Reference codebase: https://github.com/ProfEspinosaAIML/LinearRegressionArchitecture_Workshop/blob/main/UnivariateLinearRegression_Method.ipynb
Submit the Jupyter Notebook in the drop box. Do not zip the file.

During the presentation:

Use the same Jupyter Notebook you submitted to do your presentation.
The 3-5 minute timing is mandatory. The instructor will start a timer that will ring at the 5-minute mark, and you will be asked to stop. A penalty will be applied if you haven't finished your presentation.
Your score will be based on the accuracy of your code, the clarity of your data exploration, and your presentation within the 5-minute time slot.
You must present using the same Jupyter notebook you submitted the night before. Penalties apply otherwise.

### Instruction to use this repository
1. git clone https://github.com/Mostafa-Allahmoradi/Group_Presentation_5.git
2. pip install -r requirements.txt